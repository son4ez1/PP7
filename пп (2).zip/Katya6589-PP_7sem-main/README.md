login1 pass1 - оператор
login2 pass2 - менеджер
login3 pass3 - администратор
